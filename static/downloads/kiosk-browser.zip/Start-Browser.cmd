@echo off
set "WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--autoplay-policy=no-user-gesture-required"
start "" "%~dp0KioskBrowser.exe"
