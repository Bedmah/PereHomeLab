$ErrorActionPreference = "Stop"

$Url = "http://172.22.3.190/"
$ProfilePath = Join-Path $PSScriptRoot "edge-profile"
$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = "--autoplay-policy=no-user-gesture-required"

$EdgeCandidates = @(
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)

$EdgePath = $EdgeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $EdgePath) {
    throw "Microsoft Edge was not found. Install Edge or edit Start-Browser.ps1 and set EdgePath manually."
}

New-Item -ItemType Directory -Force -Path $ProfilePath | Out-Null

$Arguments = @(
    "--app=$Url",
    "--user-data-dir=$ProfilePath",
    "--no-first-run",
    "--disable-session-crashed-bubble",
    "--disable-infobars",
    "--autoplay-policy=no-user-gesture-required",
    "--start-maximized"
)

Start-Process -FilePath $EdgePath -ArgumentList $Arguments
